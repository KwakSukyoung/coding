#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

int main(int argc, char* argv[]){
    string line;
    ifstream in(argv[1]);
    int num_students;
    int num_exams;
    int NUM_GRADE = 5;
    int i;
    int j;

    // get # of students and exams
    in >> num_students >> num_exams;
    in.ignore();

    //student_list & score_list Declaration
    string* student_list = new string[num_students];
    double** score_list = new double* [num_students];
    for(i = 0; i < num_students; ++i){
        score_list[i] = new double[num_exams];
    }

    //Reading input and Saving info
    for (i = 0; i < num_students; ++i){
        getline(in,line);
        size_t P = 0;
        while(!isdigit(line[P])){
            ++P;
        }
        string exam = line.substr(P);
        string name = line.substr(0, P-1);
        student_list[i] = name;
        istringstream iss(exam);
        for (int j = 0; j <(num_exams); ++j){
            iss >> score_list[i][j];
        }
    }

    //Calculating average
    double* exam_sum = new double[num_exams];//total sum of each test
    double* individual_sum = new double [num_students];//total sum of each individual
    double* exam_average = new double [num_exams];//average of each test
    double* individual_average = new double [num_students];//average of each individual
    double total_average;
    double total_sum = 0;

    //exam sum and average
    for (i = 0; i < num_exams; ++i){
        exam_sum[i] = 0;
        for (j = 0; j < num_students; ++j){
            exam_sum[i] += score_list[j][i];
        }
        exam_average[i] = exam_sum[i]/ num_students;
    }
    //individual sum and average
    for (i = 0; i < num_students; ++i){
        individual_sum[i] = 0;
        for (j = 0; j < num_exams; ++j){
            individual_sum[i] += score_list[i][j];
        }
        individual_average[i] = individual_sum[i]/ num_exams;
    }
    //Extra Credit - average and find each individuals' grade
    for(i = 0; i < num_students; ++i){
        total_sum += individual_average[i];
    }
    total_average = total_sum/ num_students;

    //Number of each grades array + initialization
    int** number_each_grade = new int* [num_exams];
    for(i = 0; i < num_exams; ++i){
        number_each_grade[i] = new int[NUM_GRADE];
    }
    for(i = 0; i < num_exams; ++i){
        for(int j = 0; j < NUM_GRADE; ++j) {
            number_each_grade[i][j] = 0;
        }
    }

    //Individual grade array Declaration
    string** individual_grade = new string* [num_students];
    for(i = 0; i < num_students; ++i) {
        individual_grade[i] = new string[num_exams];
    }

    //listing grade array
    for(i = 0; i < num_exams; ++i){
        for(int j = 0; j < num_students; ++j) {
            if (score_list[j][i] > (exam_average[i] + 15)) {
                number_each_grade[i][0] += 1;
                individual_grade[j][i] = "(A)";
            }
            else if (score_list[j][i] > (exam_average[i] + 5)) {
                number_each_grade[i][1] += 1;
                individual_grade[j][i] = "(B)";
            }
            else if (score_list[j][i] > (exam_average[i] - 5)) {
                number_each_grade[i][2] += 1;
                individual_grade[j][i] = "(C)";
            }
            else if (score_list[j][i] > (exam_average[i] - 15)) {
                number_each_grade[i][3] += 1;
                individual_grade[j][i] = "(D)";
            }
            else {
                number_each_grade[i][4] += 1;
                individual_grade[j][i] = "(E)";
            }
        }
    }

    //final grade
    string* students_final_grade = new string[num_students];
    for (i = 0; i < num_students; ++i) {
        if(individual_average[i] > (total_average + 15)) {
            students_final_grade[i] = "(A)";
        }
        else if(individual_average[i] > (total_average + 5)) {
            students_final_grade[i] = "(B)";
        }
        else if(individual_average[i] > (total_average - 5)) {
            students_final_grade[i] = "(C)";
        }
        else if(individual_average[i] > (total_average - 15)) {
            students_final_grade[i] = "(D)";
        }
        else{
            students_final_grade[i] = "(E)";
        }
    }

    if(in.is_open()) {
        ofstream out(argv[2]);
        if (out.is_open()) {
            out << "Student Scores:" << endl;
            for (i = 0; i < num_students; ++i) {
                out << student_list[i] << " ";
                for (int j = 0; j < num_exams; ++j) {
                    out << score_list[i][j] << " ";
                }
                out << endl;
            }
            out << endl;

            out << "Exam Averages:" << endl;
            for (i = 0; i < num_exams; ++i) {
                out << "Exam " << i + 1 << " Average = ";
                out << setw(6) << setprecision(1) << fixed << exam_average[i] << endl;
            }
            out << endl;

            out << "Student Exam Grades:" << endl;
            for (i = 0; i < num_students; ++i) {
                out << student_list[i] << "\t";
                for (int j = 0; j < num_exams; ++j) {
                    out << setw(6) << setprecision(0);
                    out << score_list[i][j] << individual_grade[i][j] << " ";
                }
                out << endl;
            }
            out << endl;

            out << "Exam Grades:" << endl;
            for (i = 0; i < num_exams; ++i) {
                out << "Exam " << i + 1 << "\t";
                out << number_each_grade[i][0] << "(A)" << "\t";
                out << number_each_grade[i][1] << "(B)" << "\t";
                out << number_each_grade[i][2] << "(C)" << "\t";
                out << number_each_grade[i][3] << "(D)" << "\t";
                out << number_each_grade[i][4] << "(E)" << endl;
            }
            out << endl;

            out << "Student Final Grades:" << endl;
            for (i = 0; i < num_students; ++i) {
                out << setw(6) << setprecision(1) << fixed << student_list[i] << " " << individual_average[i];
                out << students_final_grade[i] << endl;
            }

            out << "Class Average Score = " << total_average;

            //Deleting new variables
            delete[] student_list;
            for (i = 0; i < num_students; ++i) {
                delete[] score_list[i];
            }
            delete[] score_list;
            delete[] exam_sum;
            delete[] individual_sum;
            delete[] exam_average;
            delete[] individual_average;
            for (i = 0; i < num_exams; ++i) {
                delete[] number_each_grade[i];
            }
            delete[] number_each_grade;
            for (i = 0; i < num_students; ++i) {
                delete[] individual_grade[i];
            }
            delete[] individual_grade;
            delete[] students_final_grade;


            out.close();
        } else {
            cout << "Unable to open file";
        }
        in.close();
    }
    return 0;
}



