//
// Created by Sukyoung Kwak on 3/6/23.
//

#ifndef PROJECT2_RELATION_H
#define PROJECT2_RELATION_H

#include <set>
#include <utility>

class Relation {

private:

    string name;
    Scheme scheme;
    set<Tuple> tuples;

public:
    Relation() {}

    Relation(string  name, Scheme  scheme)
            : name(std::move(name)), scheme(std::move(scheme)) { }


    void addTuple(const Tuple& tuple) {
        tuples.insert(tuple);
    }

    string toString() const {
        stringstream out;
        // fix the code to print "name=value" pairs
        for (auto& tuple: tuples)
            out << tuple.toString(scheme) << endl;
        return out.str();
    }
    Relation select(int index, const string& value) const {
        Relation result(name, scheme);
        // add tuples to the result if they meet the condition
        for (auto& tuple: tuples){
            if (tuple.at(index) == value){
                result.addTuple(tuple);
            }
        }
        return result;
    }

    Relation select(int index1, int index2) const {
        Relation result(name, scheme);
        // add tuples to the result if they meet the condition
        for (auto& tuple: tuples){
            if (tuple.at(index1) == tuple.at(index2)) { result.addTuple(tuple); }
        }
        return result;
    }

    Relation project(vector<int> indices) {
        vector<string> temp;
        for(auto index: indices){
            temp.push_back(scheme.at(index));
        }

        Scheme newScheme(temp);
        Relation result(name, newScheme);

        for (auto &tuple: tuples) {
            vector<string> newTuple;
            for (auto index: indices)newTuple.push_back(tuple.at(index));
            result.addTuple(newTuple);
        }
        return result;
    }

    Relation rename(vector<string> names) {
        Scheme newScheme(names);
        Relation result(name, newScheme);

        for (auto &tuple: tuples) result.addTuple(tuple);
        return result;
    }

    const Scheme &getScheme() const {
        return scheme;
    }

    const set<Tuple> &getTuples() const {
        return tuples;
    }

    static bool joinable(const Scheme& leftScheme, const Scheme& rightScheme,
                         const Tuple& leftTuple, const Tuple& rightTuple) {
        // add code to test whether the tuples are joinable
        bool canJoin = true;
        for(unsigned int i =0; i< leftScheme.size();++i){
            for(unsigned int j =0; j< rightScheme.size();++j){
                if((leftScheme.at(i)==rightScheme.at(j))&&(leftTuple.at(i)!= rightTuple.at(j))){
                    canJoin = false;
                }
            }
        }

        for (unsigned leftIndex = 0; leftIndex < leftScheme.size(); leftIndex++) {
            const string& leftName = leftScheme.at(leftIndex);
            const string& leftValue = leftTuple.at(leftIndex);
            cout << "left name: " << leftName << " value: " << leftValue << endl;
            for (unsigned rightIndex = 0; rightIndex < rightScheme.size(); rightIndex++) {
                const string &rightName = rightScheme.at(rightIndex);
                const string &rightValue = rightTuple.at(rightIndex);
                cout << "right name: " << rightName << " value: " << rightValue << endl;
            }
        }

        return canJoin;

    }

    Relation join(const Relation& right) {
        const Relation& left = *this;
        Relation result;
        // add code to complete the join operation
        for (const Tuple& leftTuple : left.tuples) {
            cout << "left tuple: " << leftTuple.toString(left.scheme) << endl;
            for (const Tuple& rightTuple : right.tuples) {
                cout << "right tuple: " << rightTuple.toString(right.scheme) << endl;
            }
        }
        /**
         * join the scheme
         * join the tuples
         */
        return result;
    }

    Tuple joinTuples(Tuple leftTuple, Tuple rightTuple){
        /**
         * create a new Tuple
         * if joinable then
         * add the tuple values that need something similary to the join function
         * to be joined
         */
    }

};

#endif //PROJECT2_RELATION_H
