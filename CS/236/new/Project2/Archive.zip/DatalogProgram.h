//
// Created by Sukyoung Kwak on 2/11/23.
//

#ifndef PROJECT2_DATALOGPROGRAM_H
#define PROJECT2_DATALOGPROGRAM_H

#pragma once
#include <string>
#include <sstream>
#include <vector>
#include "Token.h"
#include "Parser.h"

using namespace std;

class Parser;

class DatalogProgram{
private:
    vector<Token> tokens;
    Parser p(Token);

public:
    DatalogProgram(const vector<Token>& tokens, const Parser p(Token) ):
    tokens(tokens) { }

};

#endif //PROJECT2_DATALOGPROGRAM_H


